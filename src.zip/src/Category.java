public enum Category {
    I("I"),
    II("II"),
    III("III"),
    IV("IV"),
    NM("NM"),
    IM("IM");
    private String temp;

    Category(String im) {
        temp = im;
    }
}